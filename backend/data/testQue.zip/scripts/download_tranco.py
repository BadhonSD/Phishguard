"""Downloads the free Tranco top-1M site list used by feature_extractor.py's
web_traffic feature. Run once after cloning: python scripts/download_tranco.py"""

import io
import zipfile
from pathlib import Path

import requests

OUT_PATH = Path(__file__).resolve().parent.parent / "data" / "tranco_top1m.csv"

if __name__ == "__main__":
    OUT_PATH.parent.mkdir(exist_ok=True)
    resp = requests.get("https://tranco-list.eu/top-1m.csv.zip", timeout=60)
    resp.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
        with zf.open("top-1m.csv") as src, open(OUT_PATH, "wb") as dst:
            dst.write(src.read())
    print(f"Saved Tranco list to {OUT_PATH}")
