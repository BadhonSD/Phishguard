// Point this at your FastAPI backend. Same-origin deployments can set this to "".
const API_BASE_URL = "http://localhost:8000";

const RISK_THRESHOLDS = { green: 0.3, yellow: 0.6 };

function riskLevel(confidence) {
  if (confidence < RISK_THRESHOLDS.green) return "green";
  if (confidence < RISK_THRESHOLDS.yellow) return "yellow";
  return "red";
}

function riskLabel(level) {
  return { green: "Looks Safe", yellow: "Use Caution", red: "Likely Phishing" }[level];
}

async function checkUrlApi(url) {
  const resp = await fetch(`${API_BASE_URL}/api/check-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url }),
  });
  if (!resp.ok) {
    let detail = `Request failed (${resp.status})`;
    try {
      const body = await resp.json();
      detail = body.detail ? (Array.isArray(body.detail) ? body.detail[0].msg : body.detail) : detail;
    } catch (_) {}
    throw new Error(detail);
  }
  return resp.json();
}

// ---------- Tabs ----------

function initTabs() {
  const tabs = document.querySelectorAll("nav.tabs button");
  tabs.forEach((btn) => {
    btn.addEventListener("click", () => {
      tabs.forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.panel).classList.add("active");
      if (btn.dataset.panel === "panel-history") renderHistory();
      if (btn.dataset.panel === "panel-scan") startScanner();
      else stopScanner();
    });
  });
}

// ---------- Manual URL check ----------

function renderResultCard(container, data) {
  const level = riskLevel(data.confidence);
  const pct = Math.round(data.confidence * 100);
  const reasons = data.top_features
    .map((f) => `<li><span>${f.feature}</span><span>${f.value}</span></li>`)
    .join("");
  container.innerHTML = `
    <div class="result-card">
      <span class="badge ${level}">${riskLabel(level)} · ${pct}%</span>
      <div class="result-url">${escapeHtml(data.url)}</div>
      <p class="section-title" style="margin-top:0">Top contributing features</p>
      <ul class="reasons">${reasons}</ul>
    </div>
  `;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function initUrlForm() {
  const form = document.getElementById("url-form");
  const input = document.getElementById("url-input");
  const errorEl = document.getElementById("check-error");
  const resultEl = document.getElementById("check-result");
  const btn = document.getElementById("check-btn");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const url = input.value.trim();
    if (!url) return;

    errorEl.classList.add("hidden");
    resultEl.innerHTML = "";
    btn.disabled = true;
    btn.textContent = "Checking…";

    try {
      const data = await checkUrlApi(url);
      renderResultCard(resultEl, data);
      await addHistoryEntry({
        url: data.url,
        isPhishing: data.is_phishing,
        confidence: data.confidence,
        source: "manual",
      });
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.classList.remove("hidden");
    } finally {
      btn.disabled = false;
      btn.textContent = "Check";
    }
  });
}

// ---------- History ----------

async function renderHistory() {
  const list = document.getElementById("history-list");
  const entries = await getHistory();
  if (!entries.length) {
    list.innerHTML = `<li class="history-item">No checks yet.</li>`;
    return;
  }
  list.innerHTML = entries
    .map((e) => {
      const level = riskLevel(e.confidence);
      const pct = Math.round(e.confidence * 100);
      const when = new Date(e.timestamp).toLocaleString();
      return `
        <li class="history-item">
          <div class="history-meta">
            <span class="badge ${level}">${riskLabel(level)} · ${pct}%</span>
            <span>${e.source === "qr" ? "📷" : "⌨️"} ${when}</span>
          </div>
          <div class="history-url">${escapeHtml(e.url)}</div>
        </li>
      `;
    })
    .join("");
}

// ---------- QR scanner ----------

let qrStream = null;
let qrScanning = false;
let qrRafId = null;
let qrCanvas = null;
let qrCtx = null;

function qrElements() {
  return {
    video: document.getElementById("qr-video"),
    status: document.getElementById("scan-status"),
    scanAgainBtn: document.getElementById("scan-again-btn"),
  };
}

async function startScanner() {
  const { video, status, scanAgainBtn } = qrElements();
  scanAgainBtn.classList.add("hidden");
  hideOverlays();

  if (qrScanning) return;

  // Reuse the existing camera stream when just resuming from a freeze --
  // only prompt for a fresh getUserMedia grant if we don't already have one.
  if (!qrStream) {
    try {
      qrStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
    } catch (err) {
      status.textContent = "Camera access denied or unavailable.";
      return;
    }
    video.srcObject = qrStream;
  }

  await video.play();

  qrCanvas = qrCanvas || document.createElement("canvas");
  qrCtx = qrCanvas.getContext("2d", { willReadFrequently: true });

  qrScanning = true;
  status.textContent = "Point your camera at a QR code";
  qrRafId = requestAnimationFrame(qrTick);
}

// Releases the camera entirely -- used when navigating away from the scan tab.
function stopScanner() {
  qrScanning = false;
  if (qrRafId) cancelAnimationFrame(qrRafId);
  qrRafId = null;
  if (qrStream) {
    qrStream.getTracks().forEach((t) => t.stop());
    qrStream = null;
  }
}

// Pauses the loop and freezes the visible frame without releasing the camera,
// so "Scan Again" can resume instantly without a new permission prompt.
function freezeScanner() {
  qrScanning = false;
  if (qrRafId) cancelAnimationFrame(qrRafId);
  qrRafId = null;
  qrElements().video.pause();
}

function qrTick() {
  if (!qrScanning) return;
  const { video } = qrElements();

  if (video.readyState === video.HAVE_ENOUGH_DATA) {
    qrCanvas.width = video.videoWidth;
    qrCanvas.height = video.videoHeight;
    qrCtx.drawImage(video, 0, 0, qrCanvas.width, qrCanvas.height);
    const imageData = qrCtx.getImageData(0, 0, qrCanvas.width, qrCanvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height);
    if (code && code.data) {
      handleDecodedValue(code.data);
      return; // pause loop -- do not schedule another frame
    }
  }
  qrRafId = requestAnimationFrame(qrTick);
}

function looksLikeUrl(text) {
  return /^https?:\/\//i.test(text) || /^[\w-]+(\.[\w-]+)+(\/.*)?$/i.test(text);
}

async function handleDecodedValue(text) {
  const { status, scanAgainBtn } = qrElements();

  freezeScanner();
  scanAgainBtn.classList.remove("hidden");

  if (!looksLikeUrl(text)) {
    status.textContent = `Scanned content is not a URL: "${text}"`;
    return;
  }

  status.textContent = "Checking URL…";
  try {
    const data = await checkUrlApi(text);
    await addHistoryEntry({
      url: data.url,
      isPhishing: data.is_phishing,
      confidence: data.confidence,
      source: "qr",
    });
    showResultOverlay(data);
    status.textContent = "Point your camera at a QR code";
  } catch (err) {
    status.textContent = `Error checking URL: ${err.message}`;
  }
}

function hideOverlays() {
  document.getElementById("danger-overlay").classList.remove("active");
  document.getElementById("safe-overlay").classList.remove("active");
  document.getElementById("danger-open-link").classList.add("hidden");
  document.getElementById("danger-reveal-btn").classList.remove("hidden");
}

function showResultOverlay(data) {
  const pct = Math.round(data.confidence * 100);

  if (data.is_phishing) {
    document.getElementById("danger-confidence").textContent = `${pct}% confidence`;
    document.getElementById("danger-url").textContent = data.url;
    document.getElementById("danger-open-link").href = data.url;
    document.getElementById("danger-open-link").classList.add("hidden");
    document.getElementById("danger-reveal-btn").classList.remove("hidden");
    document.getElementById("danger-overlay").classList.add("active");
  } else {
    document.getElementById("safe-confidence").textContent = `${pct}% confidence`;
    document.getElementById("safe-url").textContent = data.url;
    document.getElementById("safe-open-btn").href = data.url;
    document.getElementById("safe-overlay").classList.add("active");
  }
}

function initOverlays() {
  document.getElementById("danger-reveal-btn").addEventListener("click", () => {
    document.getElementById("danger-reveal-btn").classList.add("hidden");
    document.getElementById("danger-open-link").classList.remove("hidden");
  });
  document.getElementById("danger-scan-again-btn").addEventListener("click", resumeScanning);
  document.getElementById("safe-scan-again-btn").addEventListener("click", resumeScanning);
}

function resumeScanning() {
  hideOverlays();
  document.getElementById("scan-again-btn").classList.add("hidden");
  startScanner();
}

document.getElementById("scan-again-btn")?.addEventListener("click", resumeScanning);

// ---------- Init ----------

initTabs();
initUrlForm();
initOverlays();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  });
}
