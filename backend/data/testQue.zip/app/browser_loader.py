from playwright.async_api import async_playwright


class BrowserBundle:
    def __init__(self):
        self._playwright = None
        self.browser = None

    async def load(self) -> None:
        self._playwright = await async_playwright().start()
        self.browser = await self._playwright.chromium.launch(headless=True)

    async def close(self) -> None:
        if self.browser:
            await self.browser.close()
        if self._playwright:
            await self._playwright.stop()

    @property
    def is_loaded(self) -> bool:
        return self.browser is not None


bundle = BrowserBundle()
